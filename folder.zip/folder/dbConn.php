<?php
    $user = "agriacok_erick";
    $host = "localhost";
    $password = "Newpass12!";
    $database = "agriacok_farmmanager";

    $connect = mysqli_connect($host, $user, $password, $database);
?>